self.description = "Test command line option (-v)"

self.args = "-v"

self.addrule("PACMAN_RETCODE=1")
